#include <QCoreApplication>
#include <QMediaPlayer>
#include <QFileInfo>

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);
    QMediaPlayer *player;
    player = new QMediaPlayer;
    player->setMedia( QUrl::fromLocalFile(QFileInfo("test.mp3").absoluteFilePath()));
    player->setVolume(50);
    player->play();
    player->setPosition(2000);
    app.exec();
}
